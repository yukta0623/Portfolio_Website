# Yukta Brahmankar — Portfolio Website

A single-page personal portfolio built with pure HTML5, CSS3, and vanilla JavaScript — no frameworks, no build tools, and no dependencies to install. Open the file and it works.

![Made with HTML5](https://img.shields.io/badge/HTML5-E34F26?style=flat&logo=html5&logoColor=white)
![Made with CSS3](https://img.shields.io/badge/CSS3-1572B6?style=flat&logo=css3&logoColor=white)
![Made with JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=flat&logo=javascript&logoColor=black)
![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)

## 🔗 Live Demo

_Add your live link here once deployed (see [Deployment](#-deployment-github-pages) below), e.g._
`https://<your-username>.github.io/yukta-portfolio-website/`

## ✨ Overview

This project is a fully responsive, self-contained portfolio page designed with a warm parchment, deep walnut, and antique gold colour palette for a professional, elegant, gender-neutral aesthetic. The profile photo is embedded directly as a Base64 data URI, so the entire site — markup, styling, behaviour, and image — lives in a single `index.html` file and can be opened offline in any browser.

## 🚀 Features

- Fully responsive layout built with CSS Grid and Flexbox
- LinkedIn-style circular profile photo
- Custom animated cursor
- Typewriter effect for rotating role titles
- Scroll-triggered reveal animations
- Animated skill progress bars
- Working contact form with success feedback
- Fixed sticky navbar with a scroll progress indicator
- Zero external JavaScript dependencies

## 🎨 Design System

| Token | Value | Purpose |
|---|---|---|
| `--bg` | `#FAFAF8` | Main background |
| `--bg2` | `#F4F1EC` | Section alternates |
| `--ink` | `#18160F` | Primary text |
| `--accent` | `#5C4A32` | Primary accent (deep walnut) |
| `--gold` | `#C4964A` | Highlight (antique gold) |
| `--teal` | `#2D5F5A` | Soft-skill accents |

All colours are defined as CSS custom properties in `:root`, so the entire theme can be re-skinned by editing a handful of variables.

**Typography:** Google Fonts, loaded via CDN for consistent, professional type across devices.

## 🗂️ Project Structure

```
yukta-portfolio-website/
├── index.html          # Entire site — markup, styles, and script in one file
├── README.md            # This file
├── LICENSE
└── .gitignore
```

## 🛠️ Getting Started

No build step, no package manager, no server required.

1. Clone the repository:
   ```bash
   git clone https://github.com/<your-username>/yukta-portfolio-website.git
   cd yukta-portfolio-website
   ```
2. Open `index.html` directly in your browser, **or** serve it locally:
   ```bash
   # Python 3
   python3 -m http.server 8000
   # then visit http://localhost:8000
   ```

## 🌐 Deployment (GitHub Pages)

1. Push this repository to GitHub (see the full step-by-step guide shared alongside this project).
2. In the repository, go to **Settings → Pages**.
3. Under **Build and deployment → Source**, select **Deploy from a branch**.
4. Choose the `main` branch and `/ (root)` folder, then click **Save**.
5. GitHub will publish the site at `https://<your-username>.github.io/yukta-portfolio-website/` within a minute or two.

## 🧩 Customisation

- **Colours:** edit the CSS variables inside `:root` at the top of the `<style>` block.
- **Content:** update the text directly inside the relevant `<section>` elements (About, Experience, Skills, Contact).
- **Photo:** replace the Base64 string in the `<img>` tag, or swap it for a normal `<img src="photo.jpg">` reference and add the image file to the repo.

## 🔮 Future Improvements

- Extract CSS/JS into separate files as the project grows
- Add a dark-mode toggle
- Connect the contact form to a real backend or form service (e.g. Formspree)

## 👤 Author

**Yukta Brahmankar**
Student, Walchand College of Engineering, Sangli

## 📄 License

This project is licensed under the [MIT License](LICENSE).
